import random
import pickle

def RochPapyeSizo(name, scores):
    print("********************************************************")
    print("**********************BYENVINI NAN JWET LA**************")
    print("********************************************************")
    LisChwa = ["R", "P", "S"]

    while True:
        ChwaJwe = input("Chwazi 'R: Roch','P:pou papye','S: pou sizo'").upper()
        print("Siw vle kite chwazi K")

        if ChwaJwe not in ["S", "R", "P", "K"]:
            print("ou fe yon move chwa, chwazi anko")
        elif ChwaJwe == "K":
            print(f"OREVWA {name}")
            break
        else:
            ChwaOdi = random.choice(LisChwa)

            if name not in scores:
                scores[name] = 0  #li met yon vale 0 si li potko egziste

            if ChwaJwe == ChwaOdi:
                print("Match nil")
                scores[name] += 0
            elif (ChwaOdi == "R" and ChwaJwe == "P") or (ChwaOdi == "P" and ChwaJwe == "S") or (ChwaOdi == "S" and ChwaJwe == "R"):
                print("Odinate a genyn")
                #anile sko negatif
                if scores[name] >= 50:
                    scores[name] -= 50
                print(f"ou pedi total pwen ou se {scores[name]}")
            else:
                print("Ou gnyn ")
                scores[name] += 50
                print(f"{name} ou genyen {scores[name]} pwen")
   
    anregistre_scores(scores)
    return scores

def anregistre_scores(scores):
    with open("data.txt","wb") as fichier:
        pickle.dump(scores,fichier)

def afiche_scores(scores):
    print("Score actuels:")
    TopJwe=sorted(scores.items(), key=lambda x: x[1]) # pou afiche pi gro sko yo avan
    for joueur, score in TopJwe():
        print(f"{joueur}:{score} pwen")

#pou fe update nan database la
        
try:
    with open("data.txt","rb") as fichier:
        scoresAvan=pickle.load(fichier)
except FileNotFoundError:
    scoresAvan={}

anregistre_scores(scoresAvan)