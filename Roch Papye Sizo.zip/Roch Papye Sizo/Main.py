import Game


def prezantasyon():
    print("********************************************************")
    print("**********************BYENVINI**************************")
    print("********************************************************")

    name=input("Rantre non'w :")
    scoresAvan=Game.scoresAvan
    

    print(f"bienvini nan jwen la {name} chwazi yon opsyon")
    while True:
        print("******************************")
        
        print("P_ pou jwe ")
        print("H_ pouw ka we reg jwet la")
        print("Z_ pou afiche sko jwe yo")
        print("K_ pouw ka kite")
    
        chwa=input(":").upper()
        if chwa=="P":
            scores= Game.RochPapyeSizo(name,scoresAvan)
    
        elif chwa=="H":
            with open("reg.txt","r") as fichier:
                
                contenue=fichier.read()
                print(contenue)
        elif chwa=="Z":
            Topjwe=Game.scoresAvan
            print(Topjwe)
        elif chwa=="K":
         print(f"! orevwa {name}")
         break


 
prezantasyon()